package passport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PassportList {
    private ArrayList<Passport> passportList;

    PassportList() {
        passportList = new ArrayList<>();
        passportList.add(new Passport(123, "Бобровский Степан Игоревич", "Студент", true));
        passportList.add(new Passport(456, "Кудж Станислав Алексеевич", "Ректор", true));
        passportList.add(new Passport(789, "Сигов Александр Сергеевич", "Президент", true));
        passportList.add(new Passport(1234, "Пушкин Александр Сергеевич", "Поэт", true));
        passportList.add(new Passport(5678, "Трамп Дональд", "Экс-президент США", false));
    }

    void addPassport(int number, String name, String position, boolean access) {
        for (int i = 0; i < passportList.size(); i++) {
            Passport passport = passportList.get(i);
            if (passport.getNumber() == number && !passport.getName().equals(name)) {
                passportList.remove(i);
                break;
            }
        }
        Passport newPassport = new Passport(number, name, position, access);
        passportList.add(newPassport);
        System.out.println("Новый пропуск был добавлен в список :)");
        printPassportList();
    }

    void printPassportList() {
        System.out.println("Список пропусков был отсортирован по ФИО:");
        passportList.sort(new Comparator<Passport>() {
            @Override
            public int compare(Passport o1, Passport o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
        for (Passport passport : passportList) {
            System.out.println(passport);
        }
        System.out.println();

        System.out.println("Список пропусков был отсортирован по номеру пропуска:");
        Collections.sort(passportList, new Comparator<Passport>() {
            @Override
            public int compare(Passport o1, Passport o2) {
                return Integer.compare(o1.getNumber(), o2.getNumber());
            }
        });
        for (Passport passport : passportList) {
            System.out.println(passport);
        }
        System.out.println();
    }

}
