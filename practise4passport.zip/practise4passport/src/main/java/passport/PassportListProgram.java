package passport;

import java.util.Scanner;

public class PassportListProgram {
    public static void main(String[] args) {
        System.out.println("РИБО-01-21, Практика №4, Вариант №4, Бобровский С.И.");
        PassportList passportList = new PassportList();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Введите номер пропуска:");
            int number = scanner.nextInt();
            System.out.println("Введите имя:");
            String name = scanner.next();
            System.out.println("Введите должность:");
            String position = scanner.next();
            System.out.println("Введите 1 для выдачи доступа или 0 для отказа в доступе:");
            boolean access = scanner.nextInt() == 1;
            passportList.addPassport(number, name, position, access);
        }
    }
}
