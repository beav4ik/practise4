package passport;


public class Passport {
    private int number;
    private String name;
    private String position;
    private boolean access;

    Passport(int number, String name, String position, boolean access) {
        this.number = number;
        this.name = name;
        this.position = position;
        this.access = access;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public boolean getAccess() {
        return access;
    }

    @Override
    public String toString() {
        return number + ", " + name + ", " + position + ", " + (access ? "Есть доступ" : "Нет доступа");
    }

}
